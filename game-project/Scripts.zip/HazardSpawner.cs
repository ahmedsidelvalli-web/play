using UnityEngine;

public class HazardSpawner : MonoBehaviour
{
    public GameObject[] hazardPrefabs;
    public float spawnInterval = 1.2f;
    public Vector2 spawnXRange = new Vector2(-3.5f, 3.5f);
    public float startY = 6.5f;

    float timer;

    void Update()
    {
        if (!GameManager.Instance.CanSpawn) return;

        timer += Time.deltaTime;
        float interval = Mathf.Max(0.25f, spawnInterval / GameManager.Instance.DifficultyMultiplier);

        if (timer >= interval)
        {
            timer = 0f;
            SpawnOne();
        }
    }

    void SpawnOne()
    {
        if (hazardPrefabs.Length == 0) return;
        int idx = Random.Range(0, hazardPrefabs.Length);
        float x = Random.Range(spawnXRange.x, spawnXRange.y);
        Vector3 pos = new Vector3(x, startY, 0f);
        var go = Instantiate(hazardPrefabs[idx], pos, Quaternion.identity);
        var h = go.GetComponent<FallingHazard>();
        if (h != null)
        {
            h.fallSpeed *= GameManager.Instance.DifficultyMultiplier;
        }
    }
}
