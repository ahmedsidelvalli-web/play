using UnityEngine;

public class FallingHazard : MonoBehaviour
{
    public float fallSpeed = 5f;
    public int damage = 1;

    void Update()
    {
        transform.position += Vector3.down * fallSpeed * Time.deltaTime;
        if (transform.position.y < -6f) Destroy(gameObject);
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            GameManager.Instance.PlayerHit(damage);
            Destroy(gameObject);
        }
    }
}
