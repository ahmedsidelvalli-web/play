using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float moveSpeed = 8f;
    public float xPadding = 0.5f;

    Camera cam;
    float minX, maxX;

    void Start()
    {
        cam = Camera.main;
        UpdateBounds();
    }

    void Update()
    {
        float input = Input.GetAxisRaw("Horizontal");

        // دعم اللمس/الماوس: يتبع الإصبع أفقياً
        if (Input.GetMouseButton(0))
        {
            Vector3 world = cam.ScreenToWorldPoint(Input.mousePosition);
            input = Mathf.Clamp((world.x - transform.position.x) * 10f, -1f, 1f);
        }

        Vector3 pos = transform.position;
        pos.x += input * moveSpeed * Time.deltaTime;
        pos.x = Mathf.Clamp(pos.x, minX + xPadding, maxX - xPadding);
        transform.position = pos;
    }

    void UpdateBounds()
    {
        Vector3 left = cam.ScreenToWorldPoint(new Vector3(0, 0, 0));
        Vector3 right = cam.ScreenToWorldPoint(new Vector3(Screen.width, 0, 0));
        minX = left.x; maxX = right.x;
    }

    void OnDrawGizmosSelected()
    {
        if (!cam) cam = Camera.main;
        if (!cam) return;
        Gizmos.color = Color.green;
        Vector3 left = cam.ScreenToWorldPoint(new Vector3(0, 0, 0));
        Vector3 right = cam.ScreenToWorldPoint(new Vector3(Screen.width, 0, 0));
        Gizmos.DrawLine(new Vector3(left.x, -5, 0), new Vector3(left.x, 5, 0));
        Gizmos.DrawLine(new Vector3(right.x, -5, 0), new Vector3(right.x, 5, 0));
    }
}
