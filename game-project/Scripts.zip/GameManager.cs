using UnityEngine;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;

    [Header("Refs")]
    public PlayerController player;
    public Text scoreText;
    public Text highScoreText;
    public GameObject revengePanel;
    public Button option1Button;
    public Button option2Button;
    public Button continueButton;

    [Header("Config")]
    public int scoreToRevenge = 50;
    public int playerHealth = 1;

    float score;
    int highScore;
    bool inRevenge;
    bool gameOver;

    public bool CanSpawn => !inRevenge && !gameOver;
    public float DifficultyMultiplier => 1f + (score / 30f); // تزداد الصعوبة تدريجيا

    void Awake()
    {
        if (Instance != null) { Destroy(gameObject); return; }
        Instance = this;
    }

    void Start()
    {
        Application.targetFrameRate = 60;
        highScore = PlayerPrefs.GetInt("HS", 0);
        UpdateUI();
        HookUI();
    }

    void Update()
    {
        if (gameOver) return;

        score += Time.deltaTime;
        if (!inRevenge && score >= scoreToRevenge)
        {
            EnterRevengePhase();
        }
        UpdateUI();
    }

    void HookUI()
    {
        if (option1Button) option1Button.onClick.AddListener(() => DoRevenge("shock"));
        if (option2Button) option2Button.onClick.AddListener(() => DoRevenge("saw"));
        if (continueButton) continueButton.onClick.AddListener(ExitRevengePhase);
    }

    void UpdateUI()
    {
        if (scoreText) scoreText.text = "Score: " + Mathf.FloorToInt(score);
        if (highScoreText) highScoreText.text = "Best: " + highScore;
    }

    public void PlayerHit(int dmg)
    {
        if (gameOver) return;
        playerHealth -= dmg;
        if (playerHealth <= 0) EndGame();
    }

    void EndGame()
    {
        gameOver = true;
        int s = Mathf.FloorToInt(score);
        if (s > highScore) { highScore = s; PlayerPrefs.SetInt("HS", highScore); }
        UpdateUI();
        UnityEngine.SceneManagement.SceneManager.LoadScene(UnityEngine.SceneManagement.SceneManager.GetActiveScene().buildIndex);
    }

    void EnterRevengePhase()
    {
        inRevenge = true;
        if (revengePanel) revengePanel.SetActive(true);
        Time.timeScale = 0f; // إيقاف الحركة أثناء الانتقام
    }

    void DoRevenge(string type)
    {
        // انتقام غير دموي: تشغيل مؤثر بسيط
        // يمكن لاحقا إضافة أنيميشن وصوت مختلف لكل نوع
        Debug.Log("Revenge: " + type);
        score += 5f; // مكافأة بسيطة
    }

    void ExitRevengePhase()
    {
        if (revengePanel) revengePanel.SetActive(false);
        Time.timeScale = 1f;
        inRevenge = false;
        scoreToRevenge += 60; // الدورة التالية أصعب
    }
}
